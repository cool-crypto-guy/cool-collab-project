extends ActionModule
class_name PlayerMovement


@export var speed : float
@export var jump_velocity : float
@export var friction = 100
@export var direction = Input.get_axis("ui_left","ui_right")
@export var acceleration = 300

func set_actions() -> void:
	actions = []
	
	actions.append(jump)
	actions.append(move)

func _ready() -> void:
	pass

func _process(delta: float) -> void:
	#add gravity
	if not get_entity().is_on_floor():
		get_entity().velocity += get_entity().get_gravity() * delta

func jump() -> void :
	get_entity().velocity.y = -jump_velocity

func move(direction : float) -> void :
	if get_entity().is_on_floor() == true:
		if direction != 0:
			get_entity().velocity.x = move_toward(get_entity().velocity.x, direction * speed, acceleration)
		else:
			get_entity().velocity.x = move_toward(get_entity().velocity.x, 0, friction)
	else:
		if direction != 0:
			get_entity().velocity.x = move_toward(get_entity().velocity.x, direction * speed * 10, acceleration * 0.01)
		else:
			pass
